import os
import sys
import string
import struct
from openpyxl import load_workbook
import xlrd

def int2hex(number, bits):
    if number < 0:
        return hex((1 << bits) + number)
    else:
        return hex(number)

def compute_srec_checksum(srec):
    """
        Compute the checksum byte of a given S-Record
        Returns: The checksum as a string hex byte (ex: "0C")
    """
    # Get the summable data from srec
    # start at 2 to remove the S* record entry
    data = srec[2:len(srec)]

    sum = 0
    # For each byte, convert to int and add.
    # (step each two character to form a byte)
    for position in range(0, len(data), 2):
        current_byte = data[position : position+2]
        int_value = int(current_byte, 16)
        sum += int_value

    # Extract the Least significant byte from the hex form
    hex_sum = hex(sum)
    least_significant_byte = hex_sum[len(hex_sum)-2:]
    least_significant_byte = least_significant_byte.replace('x', '0')

    # turn back to int and find the 8-bit one's complement
    int_lsb = int(least_significant_byte, 16)
    computed_checksum = (~int_lsb) & 0xff
    
    checksum = computed_checksum
    
    checksum = str(hex(checksum).upper())
    checksum = checksum.lstrip("0x,0X").rstrip()

    if ((checksum == '')):
        Ret = "00"
    elif ((int(checksum, 16) <= 15)):
        Ret = "0" + checksum
    else:
        Ret = checksum  
    
    return Ret

def validate_srec_checksum(srec):
    """
        Validate if the checksum of the supplied s-record is valid
        Returns: True if valid, False if not
    """
    checksum = srec[len(srec)-2:]

    # Strip the original checksum and compare with the computed one
    if compute_srec_checksum(srec[:len(srec) - 2]) == int(checksum, 16):
        return True
    else:
        return False

def float_to_hex(f):
    return hex(struct.unpack('<I', struct.pack('<f', f))[0])


    
if __name__ == "__main__":
#------------------Header Info Block Start----------------------------#
    print ".mot File Creation Started\n"
    f = open('APAR.mot', 'w')
    f.write('S0030000FC\n')
    f.write('S21400800047524D5354524D0000801610AA5AA555')
    f.write(str(compute_srec_checksum('S21400800047524D5354524D0000801610AA5AA555')))
    f.write('\n')
    f.write('S214008010000000000000000004C11DB700000000')
    f.write(str(compute_srec_checksum('S214008010000000000000000004C11DB700000000')))
    f.write('\n')
    f.write('S21400802033333333000000004D46433434300000')
    f.write(str(compute_srec_checksum('S21400802033333333000000004D46433434300000')))
    f.write('\n')
    f.write('S2140080305F4150504C3D203100000000FF0F0A01')
    f.write(str(compute_srec_checksum('S2140080305F4150504C3D203100000000FF0F0A01')))
    f.write('\n')
    print "In Progress....."
    wb = xlrd.open_workbook("VehParam.xlsx")
    sh1 = wb.sheet_by_index(1)
    
    Version = sh1.cell(rowx=0,colx=2).value
    Version = Version.replace('.', '0')
    if (len(str(Version))%2 <> 0):
        Version = "0" + Version
      
    Compatibility = sh1.cell(rowx=1,colx=2).value
    Compatibility = hex(int(Compatibility))
    Compatibility = Compatibility.lstrip("0x,0X").rstrip()
    if (len(str(Compatibility))%2 <> 0):
        Compatibility = "0" + Compatibility
    if (len(str(Compatibility)) < 8):
        Compatibility = str(Compatibility)
        while (len(str(Compatibility)) < 8):
            Compatibility = "0" + Compatibility
    Compatibility = str(Compatibility).upper()
    
    VCCpart_number = sh1.cell(rowx=2,colx=2).value
    VCCpart_number = int(VCCpart_number)
    if (len(str(VCCpart_number))%2 <> 0):
        VCCpart_number = str(VCCpart_number)
        VCCpart_number = "0" + VCCpart_number    
    if (len(str(VCCpart_number)) < 10):
        VCCpart_number = str(VCCpart_number)
        while (len(str(VCCpart_number)) < 10):
            VCCpart_number = "0" + VCCpart_number
    VCCpart_number = str(VCCpart_number).upper()
    
    SGMWpart_number = sh1.cell(rowx=3,colx=2).value
    SGMWpart_number = int(SGMWpart_number)
    if (len(str(SGMWpart_number))%2 <> 0):
        SGMWpart_number = str(SGMWpart_number)
        SGMWpart_number = "0" + SGMWpart_number    
    if (len(str(SGMWpart_number)) < 10):
        SGMWpart_number = str(SGMWpart_number)
        while (len(str(SGMWpart_number)) < 10):
            SGMWpart_number = "0" + SGMWpart_number
    SGMWpart_number = str(SGMWpart_number).upper()
    
    f.write('S214008040FF000000' + str(Version) + '02000400204E2F4100')
    f.write(str(compute_srec_checksum('S214008040FF000000' + str(Version) + '02000400204E2F4100')))
    f.write('\n') 
    
    f.write('S21400805000000010000000000000000000000000')
    f.write(str(compute_srec_checksum('S21400805000000010000000000000000000000000')))
    f.write('\n')
    
    f.write('S21400806000000000000000000000000000000000')
    f.write(str(compute_srec_checksum('S21400806000000000000000000000000000000000')))
    f.write('\n')    
   
    f.write('S21400807000000000170000000000000000000000')
    f.write(str(compute_srec_checksum('S21400807000000000170000000000000000000000')))
    f.write('\n')    
 
    f.write('S21400808000000000000000000000000000000000')
    f.write(str(compute_srec_checksum('S21400808000000000000000000000000000000000')))
    f.write('\n')    
   
    f.write('S21400809000000000000000000000000000000000')
    f.write(str(compute_srec_checksum('S21400809000000000000000000000000000000000')))
    f.write('\n')     
   
    f.write('S2140080A0' + str(VCCpart_number) + '204142' + str(SGMWpart_number) + '202042')
    f.write(str(compute_srec_checksum('S2140080A0' + str(VCCpart_number) + '204142' + str(SGMWpart_number) + '202042')))
    f.write('\n') 
    
    f.write('S2140080B0' + str(Compatibility) + '000000000000000000000000')
    f.write(str(compute_srec_checksum('S2140080B0' + str(Compatibility) + '000000000000000000000000')))
    f.write('\n')    
    
    startaddr = 32944 + 16
    AddeStr = hex(startaddr)
    while (startaddr != 33024):
        AddeStr = AddeStr.lstrip("0x,0X").rstrip()    
        f.write('S21400' + str(AddeStr.upper()) + '00000000000000000000000000000000')
        f.write(str(compute_srec_checksum('S21400' + str(AddeStr) + '00000000000000000000000000000000')))
        f.write('\n')
        startaddr = startaddr + 16
        AddeStr = hex(startaddr)
 #------------------Header Info Block End----------------------------#      
 #------------------Vehicle data Block Start-------------------------# 
    sRecord = 'S21400'
    dataAddr = 33024
    datacollect = ''
    for row_idx in range(7, sh1.nrows):
        if (len(str(datacollect)) >= 32):
            temp = hex(int(dataAddr)).upper()
            temp = temp.lstrip("0x,0X").rstrip()            
            motfilerow = sRecord + temp + datacollect[:32]
            f.write(motfilerow)
            f.write(str(compute_srec_checksum(motfilerow)))
            f.write('\n')
            dataAddr = dataAddr + 16
            datacollect = datacollect[32:]
        ParDataType = sh1.cell(rowx=row_idx,colx=2).value
        ParValue = sh1.cell(rowx=row_idx,colx=4).value
        
        if(ParDataType == "sint16"):
            ParValue = int2hex(int(ParValue),16)
            ParValue = ParValue.lstrip("0x,0X").rstrip()
            if (len(str(ParValue)) < 4):
                ParValue = str(ParValue)
                while (len(str(ParValue)) < 4):
                    ParValue = "0" + ParValue
            ParValue = str(ParValue).upper()            
            datacollect = datacollect + ParValue
            if(row_idx == 119):
                datacollect = datacollect + '0000'            
        elif(ParDataType == "sint32"):
            ParValue = int2hex(int(ParValue),32)
            ParValue = ParValue.lstrip("0x,0X").rstrip()
            if (len(str(ParValue)) < 8):
                ParValue = str(ParValue)
                while (len(str(ParValue)) < 8):
                    ParValue = "0" + ParValue
            ParValue = str(ParValue).upper()            
            datacollect = datacollect + ParValue
        elif(ParDataType == "uint16"):
            ParValue = hex(int(ParValue))
            ParValue = ParValue.lstrip("0x,0X").rstrip()
            if (len(str(ParValue)) < 4):
                ParValue = str(ParValue)
                while (len(str(ParValue)) < 4):
                    ParValue = "0" + ParValue
            ParValue = str(ParValue).upper()            
            datacollect = datacollect + ParValue
            if(row_idx == 110):
                datacollect = datacollect + '0000'            
        elif(ParDataType == "uint32"):
            ParValue = hex(int(ParValue))
            ParValue = ParValue.lstrip("0x,0X").rstrip()
            if (len(str(ParValue)) < 8):
                ParValue = str(ParValue)
                while (len(str(ParValue)) < 8):
                    ParValue = "0" + ParValue
            ParValue = str(ParValue).upper()
            if(row_idx == 126):
                ParValue = "000000" + ParValue             
            datacollect = datacollect + ParValue
            if(row_idx == 130):
                datacollect = datacollect + '000000'            
        elif(ParDataType == "float32"):
            ParValue = float_to_hex(float(ParValue))
            ParValue = ParValue.lstrip("0x,0X").rstrip()
            ParValue = ParValue.replace('L','')
            if (len(str(ParValue)) < 8):
                ParValue = str(ParValue)
                while (len(str(ParValue)) < 8):
                    ParValue = "0" + ParValue
            ParValue = str(ParValue).upper()            
            datacollect = datacollect + ParValue
        elif(ParDataType == "sint8"):
            ParValue = int2hex(int(ParValue),8)
            ParValue = ParValue.lstrip("0x,0X").rstrip()
            if (len(str(ParValue)) < 2):
                ParValue = str(ParValue)
                while (len(str(ParValue)) < 2):
                    ParValue = "0" + ParValue
            ParValue = str(ParValue).upper()            
            datacollect = datacollect + ParValue
        elif(ParDataType == "uint8"):
            ParValue = hex(int(ParValue))
            ParValue = ParValue.lstrip("0x,0X").rstrip()
            if (len(str(ParValue)) < 2):
                ParValue = str(ParValue)
                while (len(str(ParValue)) < 2):
                    ParValue = "0" + ParValue
            ParValue = str(ParValue).upper()            
            datacollect = datacollect + ParValue
            if((row_idx == 13) or (row_idx == 72) or (row_idx == 86)
               or (row_idx == 317) or (row_idx == 319) or (row_idx == 321)
               or (row_idx == 323) or (row_idx == 325) or (row_idx == 327)
               or (row_idx == 329) or (row_idx == 331)):
                datacollect = datacollect + '000000'
            if(row_idx == 48):
                datacollect = datacollect + '0000'  
            if(row_idx == 109):
                datacollect = datacollect + '00'            
        else:
            print "Wrong Data Type Entered"
        
        if((row_idx+1) == sh1.nrows):
            temp = hex(int(dataAddr)).upper()
            temp = temp.lstrip("0x,0X").rstrip() 
            while (len(str(datacollect)) < 32):
                datacollect = datacollect + "0"            
            motfilerow = sRecord + temp + datacollect[:32]
            f.write(motfilerow)
            f.write(str(compute_srec_checksum(motfilerow)))
            f.write('\n') 
            dataAddr = dataAddr + 16

 #------------------Vehicle data Block End---------------------------#
 #------------------Vehicle data Block Footer Start------------------#
while(dataAddr < 65519):
    temp = hex(int(dataAddr)).upper()
    temp = temp.lstrip("0x,0X").rstrip()            
    motfilerow = sRecord + temp + 'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'
    f.write(motfilerow)
    f.write(str(compute_srec_checksum(motfilerow)))
    f.write('\n')
    dataAddr = dataAddr + 16
motfilerow = 'S21400FFF00000000000000000504152544F564552'
f.write(motfilerow)  
f.write(str(compute_srec_checksum(motfilerow)))
f.write('\n') 
motfilerow = 'S8040080007B'
f.write(motfilerow)    
f.write('\n') 
#------------------Vehicle data Block Footer End------------------#
f.close() 

print ".mot Creation Done"


    